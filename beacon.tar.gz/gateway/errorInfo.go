package gateway

import "errors"

var (
	ErrorClose = errors.New("beacon tower is collapsed")
)
