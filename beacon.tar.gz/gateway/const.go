package gateway

const (
	subKey   = "beacontower-subscribe"
	unSubKey = "beacontower-unSubscribe"
)
