package main

import (
	"encoding/json"
	"fmt"
	"github.com/holdno/beacon/socket"
	"net"
	"sync"
	"time"
)

var Map sync.Map

func testOneMap() {
	var (
		userid int64
	)
	for i := 0; i < 100000000; i++ {
		userid = userid + 1
		Map.Store(fmt.Sprintf("/user/%d", userid), "192.168.1.1")
	}

	var s sync.WaitGroup
	s.Add(1)
	a := time.Now()
	key := "/user/199989999"
	fmt.Println(Map.Load(key))
	fmt.Println(time.Since(a))

}

func mapSlice() {
	var (
		m1 = make(map[string][]int)
		m2 = make(map[string]map[int]int)
		s  sync.WaitGroup
	)

	s.Add(1)
	go func() {

		defer s.Done()
		var wsid = 0
		for i := 0; i < 10000000; i++ {
			wsid = wsid + 1
			m1["topic1"] = append(m1["topic1"], wsid)
		}
		var (
			k int
			v int
		)
		t := time.Now()
		// m1["topic1"] = append(m1["topic1"], wsid+1)
		for k, v = range m1["topic1"] {
			//if v == 9999998 {
			//	break
			//}
		}
		fmt.Println("slice over")
		//m1["topic1"] = append(m1["topic1"][:k], m1["topic1"][k+1:]...)
		fmt.Println("slice:", time.Since(t))
		fmt.Println(k, v)
	}()

	s.Add(1)
	go func() {

		defer s.Done()
		var wsid = 0
		m2["topic1"] = make(map[int]int)
		for i := 0; i < 10000000; i++ {
			wsid = wsid + 1
			m2["topic1"][wsid] = 0
		}
		var (
			k int
			v int
		)
		t := time.Now()
		for k, v = range m2["topic1"] {

		}
		// m2["topic1"][wsid] = wsid + 1
		fmt.Println("map over")

		// delete(m2["topic1"], 9999999)
		fmt.Println("map:", time.Since(t))
		fmt.Println(k, v)
	}()

	s.Wait()
}

func main() {
	// testOneMap()

	// 验证list和slice的性能比较 增删
	// mapSlice()

	// tcp 连接测试
	// tcpConnect()

	var m sync.Map
	m.Store(1, 10)
	fmt.Println("success")
}

func tcpConnect() {
	lis, err := net.Listen("tcp", "0.0.0.0:6666")
	if err != nil {
		fmt.Println("tcp service listen error:", err)
		return
	}
	for {
		conn, err := lis.Accept()
		if err != nil {
			fmt.Println("tcp service accept error:", err)
			continue
		}
		go tcpHandler(conn)
		go heartbeat(conn)
	}
}

func tcpHandler(conn net.Conn) {
	for {
		var a = make([]byte, 1024)
		_, err := conn.Read(a)
		if err != nil {
			conn.Close()
			return
		}
		message := new(socket.TopicMessage)
		err = json.Unmarshal(a, message)
		if err != nil {
			fmt.Sprintf("topic message format error:%v\n", err)
			continue
		}
		if message.Type == socket.SubKey {

		}
	}

}

func heartbeat(conn net.Conn) {
	t := time.NewTicker(2 * time.Second)
	for {
		<-t.C
		conn.Write([]byte("heartbeat"))
	}
}
