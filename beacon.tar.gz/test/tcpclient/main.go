package main

import (
	"container/list"
	"fmt"
	"net"
	"sync"
)

func main() {
	// tcpclient()
	//ticker := time.NewTicker(1 * time.Second)
	//for {
	//	select {
	//	case <-ticker.C:
	//		fmt.Println(time.Now().Format("2006-01-02 15:04:05"))
	//	}
	//
	//}
}

func tcpclient() {
	conn, err := net.Dial("tcp", "0.0.0.0:6666")
	if err != nil {
		fmt.Println("tcp client connect error:", err)
		return
	}

	conn.Write([]byte("hi?"))
	for {
		var a = make([]byte, 1024)
		l, _ := conn.Read(a)
		fmt.Println(string(a[:l]))
	}
}

func testSyncMapAndList() {
	var m sync.Map
	l := list.New()
	l.PushBack("33333")
	l.PushBack("44")

	m.Store("123", l)
	fmt.Println(l.Len())
	m.Range(func(key, value interface{}) bool {
		table := value.(*list.List)
		for e := table.Front(); e != nil; e = e.Next() {
			if e.Value.(string) == "44" {
				table.Remove(e)
			}
		}
		return true
	})
	value, _ := m.Load("123")
	a := value.(*list.List)

	fmt.Println(a.Len())
}
